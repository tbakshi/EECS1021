
public class NumberVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("After intializing i's value to 5");
		int i = 5;
		System.out.println("i's value is: "+i);
		i = 7;
		System.out.println("After changing i's value to 7");
		System.out.println("i's value is: "+i);
		double x = 7.2;
		double y = 3.0;
		System.out.println("Average between x and y is: "+(x+y)/2);
		System.out.println("Average between 7.2 and 3.0 is: "+(7.2+3.0)/2);

	}

}
