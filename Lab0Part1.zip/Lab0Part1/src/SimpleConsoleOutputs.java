
public class SimpleConsoleOutputs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Now is Winter 2019");
		System.out.println("Hello EECS1021!");
		
	}

}
