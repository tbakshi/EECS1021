
public class RelationalOperations1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean p = 3 <5; //true
		boolean q = 5<3; //false
		
		System.out.println("3 < 5 is " +p);
		System.out.println("5 < 3 is " + q);

		//Exercises 
		boolean a = 3.5 != 1;  
		boolean b = 17*3.5 >= 67.0 - 42;
		boolean c = 9.8*54 <= 654; 
		boolean d = 6*4 == 12*2;
		boolean e = 5*2 <= 3*8;
		boolean f = 5*2 < 3*8; 
		
		
	}

}
