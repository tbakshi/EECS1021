
public class RelationalOperations2 {

	public static void main(String[] args) {
		int x = 23; 
		int y = 23; 
		System.out.println("After initializing x to 23 and y to 23.");;
		System.out.println("x==y: " + (x==y));
		System.out.println("x<y: " + (x<y));
		System.out.println("x<=y: " + (x<=y));
		System.out.println("x>=y: " + (x>=y));
		System.out.println("x>y: " + (x>y));

		x = 56; 
		y= 89;
		System.out.println("After re-assigning x to 56 and y to 89.");
		System.out.println("x==y: " + (x==y));
		System.out.println("x<y: " + (x<y));
		System.out.println("x<=y: " + (x<=y));
		System.out.println("x>=y: " + (x>=y));
		System.out.println("x>y: " + (x>y));

		
		x = 101; 
		y= 48;
		System.out.println("After re-assigning x to 101 and y to 48.");
		System.out.println("x==y: " + (x==y));
		System.out.println("x<y: " + (x<y));
		System.out.println("x<=y: " + (x<=y));
		System.out.println("x>=y: " + (x>=y));
		System.out.println("x>y: " + (x>y));


	}

}
