
public class WhileLoop {

	public static void main(String[] args) {
		int i =1; 
		while (i<=3) {
			System.out.println("i is " + i);
			i++; 
		}
		
	}

}
