
public class LogicalOperations1 {

	public static void main(String[] args) {
		/*Logical Operators 
		 * 1. Logical negations (not) 
		 * 2. Logical conjunction (and)
		 * 3. Logical disjunction (or) 
		 */
		
		boolean p = true; 
		boolean negation = !p; 
		System.out.println("Logical negation of p being " + p + "is: " + negation);
		
		p = false; 
		negation = !p; 
		System.out.println("Logical negation of p being " + p + "is: " + negation);

	
		
	}

}
