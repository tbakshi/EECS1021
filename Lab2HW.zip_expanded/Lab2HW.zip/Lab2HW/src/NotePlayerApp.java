

public class NotePlayerApp 
{
	public static void main(String[] args)
	{
		NotePlayer notePlayer = new NotePlayer(true);
		notePlayer.startMonitoring();
	}
}
