
public class StringVariables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String firstName = "";
		String lastName = "";
		int i = 0;
		System.out.println("Person  " + i + ": "+ firstName + ", " + lastName);
		firstName = "Heeyeon";
		lastName = "Kang";
		i = i + 1;
		System.out.println("Person  " + i + ": "+ firstName + ", " + lastName);
		firstName = "Jihye";
		lastName = "Park";
		i = i + 1;
		System.out.println("Person  " + i + ": "+ firstName + ", " + lastName);
	}

}
