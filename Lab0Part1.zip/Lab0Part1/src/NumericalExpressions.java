
public class NumericalExpressions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(15+4);
		System.out.println(15-4);
		System.out.println(15*4);
		System.out.println(15/4);
		System.out.println(23/4);
		System.out.println(23%4);
		System.out.println("1+1");
	}

}
